#include <Arduino.h>

#include <ESP8266WiFi.h>

#include <WiFiClient.h>

#include <HTTPClient.h>

#include <ESP8266httpUpdate.h>

const char* ssid = "ssid";
const char* password = "pass";

#define _STATUS_LED_CONNEXION_ON_
#define _HOSTNAME_ "TEST_Auto_Update"
//---------------------------------------------------------------
#define DEBUG_AUTOUPDATE_ESP8266

// Exemple avec des fichiers héberger sur le site de free.fr
#define FIRMWARE_URL_BIN   "http://site.free.fr/path_firmware/firmware.bin";
#define FIRMWARE_URL_TXT   "http://site.free.fr/path_firmware/firmware.txt"

#define HOST_UPDATE  "site.free.fr"
#define PATH_UPDATE "/path_firmware/"
#define FILE_UPDATE_TXT "firmware.txt"
#define FILE_UPDATE_BIN "firmware.bin"

#define FIRMWARE_VERSION "0.8"

#include <AutoUpdate_ESP8266.h>
//---------------------------------------------------------------
byte mac[6];
char MAC_str[20];
String s_ChipId;
String s_version;
String s_hostname;
String ipStr, gatewayIP_Str, dnsStr;
IPAddress ip;
int status_connexion;
float rssi_moy;
int connexion_error = 0, nb_wait = 0;


//------------------------------------------
// t_fct : Temp de fonctionnement en secondes
unsigned long t0_fct;
float t_fct;

void INIT_Temp_fct()
{
 t0_fct = millis();	
}

void Calcule_Temp_fct() // Temp de fonctionnement en secondes
{
 t_fct = 0.001 * (float)(millis() - t0_fct); 
}
//------------------------------------------
float Moyenne_10(float Moy, float val);

/*
https://www.tala-informatique.fr/wiki/index.php/Esp8266_wifi

Programmation évènementielle
Il est possible de définir une fonction de callback qui sera appelée lorsqu'un événements arrive. Les événements possibles sont les suivants :

Événement	  Description	                                            Mode
AP	        WiFi.onSoftAPModeStationConnected(<function>)	          Connexion d'un client
AP	        WiFi.onSoftAPModeStationDisconnected(<function>)	      Déconnexion d'un client
client	    WiFi.onStationModeAuthModeChanged(<function>)	          Changement du mode d'authentification
client	    WiFi.onStationModeConnected(<function>)	                Connexion au réseau réussie
client	    WiFi.onStationModeDHCPTimeout(<function>)	              Configuration DHCP non reçue
client	    WiFi.onStationModeGotIP(<function>)	                    Configuration OSI 3 reçue
client	    WiFi.onStationModeDisconnected(<function>)	            Déconnexion du réseau
*/
// Gestion des évènements du Wifi
void OnConnected(const WiFiEventStationModeConnected& event);
void OnGotIP(const WiFiEventStationModeGotIP& event);
void OnDisconnected(const WiFiEventStationModeDisconnected& event);

// RSSI
void INIT_RSSI(void);
void Calcule_RSSI(void);

// Initialisation connexion WIFI
void Init_WIFI(void);
void status_connexion_WIFI(void);

// Force signal
String Acceptable_Signal(float rssi_val);

//WiFiClient  client;

int etat_update = 0;

void Separateur_Simple_Serial(void)
{
  Serial.println("--------------");
}

float Moyenne_10(float Moy, float val)
{
 Moy = 0.1 * (9.0 * Moy + val);  

 return Moy;
}

// Gestion des évènements du Wifi
void OnConnected(const WiFiEventStationModeConnected& event)
{
 status_connexion = 1;
 Serial.println("\nWifi Connected"); 
}

void OnGotIP(const WiFiEventStationModeGotIP& event)
{
 ip = WiFi.localIP();
 ipStr = WiFi.localIP().toString(); 
 gatewayIP_Str = WiFi.gatewayIP().toString();
 dnsStr = WiFi.dnsIP().toString();
 WiFi.macAddress(mac);
 
 snprintf(MAC_str, sizeof MAC_str, "%02x:%02x:%02x:%02x:%02x:%02x", mac[0], mac[1], mac[2], mac[3], mac[4], mac[5]);

 Serial.print("\n\rMAC : "); 
 Serial.println( MAC_str ); 
 Serial.println("Adresse IP : " + ipStr ); 
 Serial.println("Passerelle IP : " + gatewayIP_Str ); 
 Serial.println("DNS IP : " + dnsStr ); 
 Serial.print("Puissance de réception : ");
 Calcule_RSSI();
 Serial.print( rssi_moy );
 Serial.println("dBm");
}

void OnDisconnected(const WiFiEventStationModeDisconnected& event)
{
 Serial.println("\nWifi Disconnected");
 status_connexion = 0;
}

void status_connexion_WIFI(void)
{
 // la LED_BUILTIN correspond au D4 du GPIO2
 
 switch(WiFi.status())
 {
      case WL_NO_SSID_AVAIL:
        //Serial.println("Configured SSID cannot be reached");
		    status_connexion = 0;
        break;
      case WL_CONNECTED:
        //Serial.println("Connection successfully established");
		    status_connexion = 1;
		    #ifdef _STATUS_LED_CONNEXION_ON_
        digitalWrite(LED_BUILTIN, LOW);   // Connecter, LED allumé / Turn the LED on (Note that LOW is the voltage level
        #endif
        break;
      case WL_CONNECT_FAILED:
        //Serial.println("Connection failed");
		    status_connexion = 0;
		    #ifdef _STATUS_LED_CONNEXION_ON_
        digitalWrite(LED_BUILTIN, HIGH);  // Non Connecter, LED éteinte / Turn the LED off by making the voltage HIGH
        #endif
        break;
 }
}

void INIT_RSSI(void)
{
	float rssi = WiFi.RSSI();
    if(isnan(rssi))
    {
     Serial.println("Failed to read from rssi!");
	   rssi = -120.0;
     return;
    }
    else  rssi_moy = rssi; // Moyenne sur 10 valeurs
}

void Calcule_RSSI(void)
{
	float rssi = WiFi.RSSI();
    if(isnan(rssi))
    {
     Serial.println("Failed to read from rssi!");
     return;
    }
    else  rssi_moy = Moyenne_10(rssi_moy, rssi); // Moyenne sur 10 valeurs
}

// Initialisation connexion WIFI
void Init_WIFI(void)
{
 #ifdef _STATUS_LED_CONNEXION_ON_
 pinMode(LED_BUILTIN, OUTPUT);     // Initialize the LED_BUILTIN pin as an output
 #endif
 //wdt_reset(); 	
 Serial.print("Chip ID: 0x");
 s_ChipId = String(ESP.getChipId(), HEX);

 Serial.println(s_ChipId);

 s_version = String(__DATE__)+ "-" + String(__TIME__);
  
 // Set Hostname.
 s_hostname = String(_HOSTNAME_);
 
 //s_hostname += "-" + s_ChipId;// + "-" + s_version;
 WiFi.hostname(s_hostname);

 //wdt_reset();
 
 // Print hostname.
 Serial.println("Hostname: " + s_hostname);
 Serial.println(WiFi.hostname());
  
 WiFi.mode(WIFI_STA);
 WiFi.begin(ssid, password);

 #ifdef _IP_FIXE_
 WiFi.config(ip, gateway, subnet);
 #endif	
 
 WiFi.macAddress(mac);
 
 snprintf(MAC_str, sizeof MAC_str, "%02x:%02x:%02x:%02x:%02x:%02x", mac[0], mac[1], mac[2], mac[3], mac[4], mac[5]);

 Serial.print("\n\rMAC : "); 
 Serial.println( MAC_str ); 

 static WiFiEventHandler OnConnectedHandler = WiFi.onStationModeConnected(OnConnected);
 static WiFiEventHandler OnGotIPHandler = WiFi.onStationModeGotIP(OnGotIP);
 static WiFiEventHandler OnDisconnectedHandler = WiFi.onStationModeDisconnected(OnDisconnected);

 Serial.println("");
 // Wait for connection ----------------------------
 
 while( (WiFi.status() != WL_CONNECTED) && (nb_wait <= 100) ) // sort de la boucle si ça dure plus que 100x 
 {
  #ifdef _STATUS_LED_CONNEXION_ON_
  digitalWrite(LED_BUILTIN, LOW);   // Connecter, LED allumé / Turn the LED on (Note that LOW is the voltage level
  #endif

  delay(50);
  #ifdef _STATUS_LED_CONNEXION_ON_
  digitalWrite(LED_BUILTIN, HIGH);  // Non Connecter, LED éteinte / Turn the LED off by making the voltage HIGH
  #endif
 
  delay(50);
  nb_wait++;

  Serial.print("nb_wait : ");
  Serial.print(nb_wait);
  Serial.print(" / MAC : "); 
  Serial.println( MAC_str ); 
 }
 
 //The ESP8266 tries to reconnect automatically when the connection is lost
 WiFi.setAutoReconnect(true);
 WiFi.persistent(true);
  
 status_connexion_WIFI();

 INIT_RSSI();
}
//-------------------------------------------

void setup() 
{
  Serial.begin(115200);
  //   Serial.setDebugOutput(true);
 
  Serial.println();
  Serial.println();
  Serial.println();
 
  for (uint8_t t = 4; t > 0; t--) {
    Serial.printf("[SETUP] WAIT %d...\n", t);
    Serial.flush();
    delay(1000);
  }

  Serial.print(F("Firmware Version actual : "));
  Serial.println(FirmwareVersion);

  Separateur_Simple_Serial();

  Init_WIFI();
}
 
float t = 0.0;

void STATUS_IOT(void)
{
   Serial.print(t);
   Serial.print(" secondes");

   Serial.print(" / Puissance de réception : ");
   Calcule_RSSI();
   Serial.print( rssi_moy );
   Serial.print("dBm");

   if(status_connexion == 1)  Serial.println(" / CONNECTED");
   else Serial.println(" / NOT CONNECTED");
}

void loop() 
{
  STATUS_IOT();
   
  if(status_connexion == 1)
  {  
    AutoUpdate();
  }

  delay(1000); // Wait a second and restart
  t += 1.0;
  Serial.println("==============================================================");
    // Délai de 1 heure avant la prochaine mise à jour
  //delay(3600000);
}
